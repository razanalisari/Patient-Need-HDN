/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hdn;

/**
 *
 * @author pc
 */
public class Appointment {
    private String AppointmentDate;
    private String AppointmentTime;
    private int patientId;
    private int doctorId;
    private int index;
    public Appointment() {
    }

    public Appointment(String AppointmentDate, String AppointmentTime, int patientId, int doctorId) {
        this.AppointmentDate = AppointmentDate;
        this.AppointmentTime = AppointmentTime;
        this.patientId = patientId;
        this.doctorId = doctorId;
    }
    public void ToString()
    {
        System.out.println("ID: "+index+" Date: " +AppointmentDate +"\t"+" Time: "+AppointmentTime+"\t"
        +" Doctor: "+HDNData.getPersonById(doctorId).getFullName()+"\t"
        +" Patient: "+HDNData.getPersonById(patientId).getFullName() +"\t"
        
        );
    }
    
    /**
     * @return the AppointmentDate
     */
    public String getAppointmentDate() {
        return AppointmentDate;
    }

    /**
     * @param AppointmentDate the AppointmentDate to set
     */
    public void setAppointmentDate(String AppointmentDate) {
        this.AppointmentDate = AppointmentDate;
    }

    /**
     * @return the AppointmentTime
     */
    public String getAppointmentTime() {
        return AppointmentTime;
    }

    /**
     * @param AppointmentTime the AppointmentTime to set
     */
    public void setAppointmentTime(String AppointmentTime) {
        this.AppointmentTime = AppointmentTime;
    }

    /**
     * @return the patientId
     */
    public int getPatientId() {
        return patientId;
    }

    /**
     * @param patientId the patientId to set
     */
    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    /**
     * @return the doctorId
     */
    public int getDoctorId() {
        return doctorId;
    }

    /**
     * @param doctorId the doctorId to set
     */
    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    /**
     * @param index the index to set
     */
    public void setIndex(int index) {
        this.index = index;
    }
 
    
}
