/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hdn;

/**
 *
 * @author pc
 */
import java.util.Date;
import java.util.InputMismatchException;

public class Doctor extends Person {

    private String specalize;
    private String address;

    public Doctor(String specalize, String address, int id, String phone, String Email, String UserName, String password, String FullName) {
        super(id, phone, Email, UserName, password, FullName);
        this.specalize = specalize;
        this.address = address;
    }

    

    public void DisplayMenu() {
        int choice = 1;
        String Main_Menu = "\n.............Doctor Menu.............\n"
                + "1-View Reserving Appointments\n"
                + "2-View Patients \n"
                + "3-View Nurses \n"
                + "4-Add Preview\n"
                + "5-Sign out \n"
                + "Your option : ";
        while (choice != 5) {
            System.out.println(Main_Menu);
                choice = HDNData.reader.nextInt();
                switch (choice) {
                    case 1: {
                        Appointments();
                        break;
                    }
                    case 2: {
                        Patients();
                        break;
                    }
                    case 3: {
                        Nurses();
                        break;
                    }
                    case 4: {
                        AddPreview();
                        break;
                    }
                    case 5: {
                        break;
                    }

                }
           
        }
    }

    public void ToString() {
        super.ToString();
        System.out.println(" Specalize: " + specalize + "\t" + " address: " + address + "\t");
    }

    void Appointments() {
        for (int i = 0; i < HDNData.Appointment.size(); i++) {
            HDNData.Appointment.get(i).setIndex(i+1);
            if(HDNData.Appointment.get(i).getDoctorId()==getId())
            HDNData.Appointment.get(i).ToString();
        }
    }

    void Patients() {
        for (int i = 0; i < HDNData.HDNUsers.size(); i++) {
            if (HDNData.HDNUsers.get(i) instanceof Patient) {
                HDNData.HDNUsers.get(i).ToString();
                  System.out.println("------------------------------------------------------------------------------------");
            }
        }
    }

    void Nurses() {
        for (int i = 0; i < HDNData.HDNUsers.size(); i++) {
            if (HDNData.HDNUsers.get(i) instanceof Nurse) {
                HDNData.HDNUsers.get(i).ToString();
                  System.out.println("------------------------------------------------------------------------------------");
            }
        }
    }

    void AddPreview() {
        Appointments();
            System.out.println("\n enter Appointment ID\n");
            int x = HDNData.reader.nextInt();
            Appointment appointment = HDNData.getAppointmentById(x);
            if (appointment != null) {
                System.out.println("\n enter Surgeons list\n");
                String Surgeons = HDNData.reader.next();
                System.out.println("\n enter Review Date list\n");
                String ReviewDate = HDNData.reader.next();
                 System.out.println("\n enter Review Note list\n");
                 String PreviewNote = HDNData.reader.next();
                 Preview preview=new Preview(appointment, Surgeons, ReviewDate, PreviewNote);
                  HDNData.Previews.add(preview);
                  System.out.println("\n Preview Added Successfully\n");
            } else {
                System.out.println("\n Appointment not exists\n");
            }
          
        
    }

    /**
     * @return the specalize
     */
    public String getSpecalize() {
        return specalize;
    }

    /**
     * @param specalize the specalize to set
     */
    public void setSpecalize(String specalize) {
        this.specalize = specalize;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

}
