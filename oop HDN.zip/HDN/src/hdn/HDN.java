/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hdn;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author pc
 */
public class HDN {

    static Scanner reader = new Scanner(System.in);
    static String WELCOMEMSG = "\n.............WELCOME TO HDN PROGRAM.............\n"
            + "Do You have account ?"
            + "\n n: create new account"
            + "\n y: sign in "
            + "\n e: exit program?";

    ;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Person person = new Doctor("Stomache", "Jeddeh", HDNData.HDNUsers.size() + 1,
                "0096394232432", "sami@gmail.com", "d", "d","Sami Bitar");
        HDNData.HDNUsers.add(person);
        person = new Nurse(1, "Operations", HDNData.HDNUsers.size() + 1, "0096394232472", "nurse1@gmail.com", "n", "n"
        ,"Amal Alrajhi"
        );
        HDNData.HDNUsers.add(person);
        person = new Patient(20, true, "has covid 19", HDNData.HDNUsers.size() + 1, "0096394232472", "patient@gmail.com", "p", "p"
        ,"Reem Muhamad");
        HDNData.HDNUsers.add(person);
         person = new Patient(25, false, "has headache", HDNData.HDNUsers.size() + 1, "0096394232999", "patient22@gmail.com", "p2", "p2"
        ,"Ali Rahwan");
         Appointment a=new Appointment("12/12/2021", "3:30", 3, 1);
          HDNData.Appointment.add(a);
          a=new Appointment("12/12/2021", "3:45", 4, 1);
           HDNData.Appointment.add(a);
        HDNData.HDNUsers.add(person);
        HDNData.reader = reader;
        boolean end = false;
        do {
            System.out.println(WELCOMEMSG);
                String c = reader.next().toLowerCase();
                switch (c) {
                    case "y": {
                        signIn();
                        break;
                    }
                    case "n": {
                        createAccount();
                        break;
                    }
                    case "e": {
                        end = true;
                        break;
                    }

                }
            
        } while (!end);
        //Doctor doctor=new Doctor();

    }

    static void signIn() {
        System.out.println("LOGIN ");
        System.out.println("enter user name");
        String userName = reader.next();
        System.out.println("enter password");
        String password = reader.next();
        if (validate(userName, password)) {
            Person p = HDNData.getUserByData(userName, password);
            if (p instanceof Doctor) {
                Doctor d = (Doctor) p;
                d.DisplayMenu();
            } else if (p instanceof Nurse) {
                Nurse n = (Nurse) p;
                n.DisplayMenu();
            } else if (p instanceof Patient) {
                Patient pp = (Patient) p;
                pp.DisplayMenu();
            }

        } else {
            System.out.println("Invalid username or password");
        }
    }

    static void createAccount() {
        System.out.println("create account ");
        System.out.println("enter Name ");
        String Name = reader.next();
        System.out.println("enter password ");
        String password = reader.next();
        System.out.println("enter Email");
        String Email = reader.next();
        System.out.println("enter Phone");
        String Phone = reader.next();
        System.out.println("enter Person name");
        String FullName = reader.next();
        String msg = "Select account type ?"
                + "\n d: create Doctor account"
                + "\n n: create Nurse account"
                + "\n p: create Patient account";
        ;
        Person person;
        System.out.println(msg);
            String inp = reader.next();
            if (inp.length() > 0) {
                String choice = inp.substring(0, 1);
                if (choice.equals("d") || choice.toLowerCase().equals("d")) {
                    System.out.println("enter doctor specalize");
                    String specalize = reader.next();
                    System.out.println("enter doctor address");
                    String address = reader.next();
                    person = new Doctor(specalize, address, HDNData.HDNUsers.size() + 1, Phone, Email, Name, password,FullName);
                    HDNData.HDNUsers.add(person);
                } else if (choice.equals("p") || choice.toLowerCase().equals("p")) {
                    int age = 30;
                        System.out.println("\n enter age\n");
                        age = reader.nextInt();
                  
                    boolean isFemale = false;

                        msg = "Select gender ?"
                                + "\n f: Female"
                                + "\n m: Male";
                        System.out.println(msg);
                            String c = reader.next().toLowerCase();
                            switch (c) {
                                case "f": {
                                    isFemale = true;
                                    break;
                                }
                                case "m": {
                                    isFemale = false;
                                    break;
                                }
                                default: {
                                    System.err.println("Invalid input");
                                    return;
                                }

                            }
                       
                      
                        System.out.println("\n enter if there is notes\n");
                        String notes = reader.next();
                      
                        person = new Patient(age, isFemale, notes, HDNData.HDNUsers.size() + 1, Phone, Email, Name, password,FullName);
                        HDNData.HDNUsers.add(person);

                   

                } else if (choice.equals("n") || choice.toLowerCase().equals("n")) {
                        System.out.println("enter Nurse Number");
                        int NurseNumber = reader.nextInt();
                        System.out.println("enter Nurse Department ");
                        String Department = reader.next();
                        person = new Nurse(NurseNumber, Department, HDNData.HDNUsers.size() + 1, Phone, Email, Name, password,FullName);
                        HDNData.HDNUsers.add(person);
                   

                } else {
                    System.err.println("only one char d or n or p");
                    reader.nextLine();
                    return;
                }
                System.out.println("Account Created :)");
            } else {
                System.err.println("only one char d or n or p");
                reader.nextLine();
            }
       

    }

    static boolean validate(String userName, String password) {
        if (HDNData.validateUser(userName, password)) {
            return true;
        }
        return false;
    }

}
