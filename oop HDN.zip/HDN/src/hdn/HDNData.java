/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hdn;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author pc
 */
public class HDNData {
     public static Scanner reader;
     public static ArrayList<Person> HDNUsers = new ArrayList<>();
     public static ArrayList<Appointment> Appointment = new ArrayList<>();
      public static ArrayList<Preview> Previews = new ArrayList<>();
     
     
     
     public static boolean validateUser(String userName,String password)
     {
         for (int i = 0; i <HDNUsers.size() ; i++) {
             if(HDNUsers.get(i).getPassword().equals(password)
                &&  
                HDNUsers.get(i).getUserName().equals(userName)     
               )
             {
                 return true;
             }
         }
         return false;
     }
      public static Person getUserByData(String userName,String password)
     {
         for (int i = 0; i <HDNUsers.size() ; i++) {
             if(HDNUsers.get(i).getPassword().equals(password)
                &&  
                HDNUsers.get(i).getUserName().equals(userName)     
               )
             {
                 return HDNUsers.get(i);
             }
         }
         return null;
     }
   public static Person getPersonById(int personId)
     {
          for (int i = 0; i <HDNUsers.size() ; i++) {
             if(HDNUsers.get(i).getId()==personId)
             {
                 return HDNUsers.get(i);
             }
         }
          return null;
     }
    public static Person getPtientById(int personId)
     {
          for (int i = 0; i <HDNUsers.size() ; i++) {
             if(HDNUsers.get(i).getId()==personId)
             {
                 if(HDNUsers.get(i) instanceof Patient)
                 return HDNUsers.get(i);
             }
         }
          return null;
     }
    public static Person getDoctorById(int personId)
     {
          for (int i = 0; i <HDNUsers.size() ; i++) {
             if(HDNUsers.get(i).getId()==personId)
             {
                 if(HDNUsers.get(i) instanceof Doctor)
                 return HDNUsers.get(i);
             }
         }
          return null;
     }
    
   
   public static Appointment getAppointmentById(int Id)
     {
          for (int i = 0; i <Appointment.size() ; i++) {
             if(i==(Id-1))
             {
                 return Appointment.get(i);
             }
         }
          return null;
     }
   public static void ViewDoctors()
     {
         for (int i = 0; i <HDNUsers.size() ; i++) {
             if(HDNUsers.get(i) instanceof Doctor)
             {
                  HDNUsers.get(i).ToString();
             }
         }
     }
    public static void ViewPatients()
     {
         for (int i = 0; i <HDNUsers.size() ; i++) {
             if(HDNUsers.get(i) instanceof Patient)
             {
                  HDNUsers.get(i).ToString();
             }
         }
     }
   
}
