/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hdn;

/**
 *
 * @author pc
 */
import java.util.*;

/**
 *
 * @author 96650
 */
public class Nurse extends Person{
 private int NurseNumber;
 private String Department;

    public Nurse(int NurseNumber, String Department, int id, String phone, String Email, String UserName, String password, String FullName) {
        super(id, phone, Email, UserName, password, FullName);
        this.NurseNumber = NurseNumber;
        this.Department = Department;
    }

   
       public void ToString()
    {
        super.ToString();
        System.out.println(" Nurse Number: " +NurseNumber +"\t"+" Department: "+Department+"\t");
    }
      public void DisplayMenu() {
        int choice = 1;
        String Main_Menu = "\n.............Nurse Menu.............\n"
                + "1-All Appointments\n"
                + "2-Get Doctor Appointments \n"
                + "3-Get Patient Appointments \n"
                + "4-New Appointment\n"
                + "5-Sign out\n"
                + "Your option : ";
        while (choice != 5) {
            System.out.println(Main_Menu);
                choice = HDNData.reader.nextInt();
                switch (choice) {
                    case 1: {
                        AllAppointments();
                        break;
                    }
                    case 2: {
                        ViewDoctorAppointments();
                        break;
                    }
                    case 3: {
                        PatientAppointments();
                        break;
                    }
                     case 4: {
                       NewAppointment(); 
                        break;
                    }
                    case 5: {
                        break;
                    }
                 
                }
           
        }
    }   

      void AllAppointments() {
        for (int i = 0; i < HDNData.Appointment.size(); i++) {
            HDNData.Appointment.get(i).setIndex(i+1);
            HDNData.Appointment.get(i).ToString();
        }
    }
      void ViewDoctorAppointments()
      {
            System.out.println("\n enter Doctor ID\n");
            int x = HDNData.reader.nextInt();
            Doctor doctor =(Doctor) HDNData.getDoctorById(x);
            if (doctor != null) {
             doctor.Appointments();
            } else {
                System.out.println("\n Doctor not exists\n");
            }
      }
       void PatientAppointments()
      {
            System.out.println("\n enter Patient ID\n");
            int x = HDNData.reader.nextInt();
            Patient p =(Patient) HDNData.getPtientById(x);
            if (p != null) {
              p. Appointments();
            } else {
                System.out.println("\n Patient not exists\n");
            }
          
       
      }
      
     
        void NewAppointment() {
          System.out.println("\n Doctors List\n");
          HDNData.ViewDoctors();
            System.out.println("\n enter Doctor ID\n");
            int x = HDNData.reader.nextInt();
            Doctor doctor =(Doctor) HDNData.getDoctorById(x);
            if (doctor != null) {
                System.out.println("\n enter Appointment Date\n");
                String AppointmentDate = HDNData.reader.next();
                System.out.println("\n enter Appointment Time \n");
                String AppointmentTime = HDNData.reader.next();
                 System.out.println("\n Patients List\n");
                 HDNData.ViewPatients();    
            System.out.println("\n enter Patient ID\n");
            
            int pId = HDNData.reader.nextInt();
            Patient p =(Patient) HDNData.getPtientById(pId);
            if (p != null) {
                System.out.println("\n enter Appointment Date\n");
               
                Appointment appointment=new Appointment(AppointmentDate, AppointmentTime,  p.getId(),doctor.getId());
                  HDNData.Appointment.add(appointment);
                  System.out.println("\n appointment Added Successfully\n");
            } else {
                System.out.println("\n Patien not exists\n");
                return;
            }
          
            }
             else {
                System.out.println("\n Doctor not exists\n");
                return;
            }
          
       
    }
   
    /**
     * @return the NurseNumber
     */
    public int getNurseNumber() {
        return NurseNumber;
    }

    /**
     * @param NurseNumber the NurseNumber to set
     */
    public void setNurseNumber(int NurseNumber) {
        this.NurseNumber = NurseNumber;
    }

    /**
     * @return the Department
     */
    public String getDepartment() {
        return Department;
    }

    /**
     * @param Department the Department to set
     */
    public void setDepartment(String Department) {
        this.Department = Department;
    }


}

