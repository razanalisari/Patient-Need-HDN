/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hdn;

/**
 *
 * @author pc
 */
import java.util.Date;
import java.text.SimpleDateFormat;
/**
 *
 * @author 96650
 */
public class Patient extends Person{
 private int age;  
 private boolean isFemale; 
 private String notes;

    public Patient() {
    }

    public Patient(int age, boolean isFemale, String notes, int id, String phone, String Email, String UserName, String password, String FullName) {
        super(id, phone, Email, UserName, password, FullName);
        this.age = age;
        this.isFemale = isFemale;
        this.notes = notes;
    }

    
      public void ToString()
    {
        super.ToString();
        String g="";
         if(isFemale)
           g=" gender: Female"; 
        else
            g=" gender: Male"; 
        System.out.println(" age: " +age +"\t"+" notes: "+notes+"\t"+g+"\n" );
        for (int i = 0; i < HDNData.Previews.size(); i++) {
            if(HDNData.Previews.get(i).getAppointment().getPatientId()==getId())
            {
                HDNData.Previews.get(i).ToString();
            }
        }
    }
     public void DisplayMenu() {
        int choice = 1;
        String Main_Menu = "\n.............Patient Menu.............\n"
                + "1-MY Appointments\n"
                + "2-Last Previews \n"
                + "3-Sign out\n"
                + "Your option : ";
        while (choice != 3) {
            System.out.println(Main_Menu);
                choice = HDNData.reader.nextInt();
                switch (choice) {
                    case 1: {
                         Appointments();
                        break;
                    }
                    case 2: {
                        LastPreviews();
                        break;
                    }
                    case 3: {
                        break;
                    }
                 
                }
            
        }
    }
      void Appointments() {
        for (int i = 0; i < HDNData.Appointment.size(); i++) {
            HDNData.Appointment.get(i).setIndex(i+1);
            if( HDNData.Appointment.get(i).getPatientId()==getId())
            HDNData.Appointment.get(i).ToString();
        }
    }
    void LastPreviews() {
        for (int i = 0; i < HDNData.Previews.size(); i++) {
            if( HDNData.Previews.get(i).getAppointment().getPatientId()==getId())
                HDNData.Previews.get(i).ToString();
        }
    }
   
    
    /**
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * @return the isFemale
     */
    public boolean isIsFemale() {
        return isFemale;
    }

    /**
     * @param isFemale the isFemale to set
     */
    public void setIsFemale(boolean isFemale) {
        this.isFemale = isFemale;
    }

    /**
     * @return the notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * @param notes the notes to set
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }



}

