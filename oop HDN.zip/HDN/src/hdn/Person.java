/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hdn;

/**
 *
 * @author pc
 */
public class Person {
    private int id;
    private String phone;
    private String Email;
    private String UserName;
    private String password;
    private String FullName;
    public Person() {
    }

    public Person(int id, String phone, String Email, String UserName, String password, String FullName) {
        this.id = id;
        this.phone = phone;
        this.Email = Email;
        this.UserName = UserName;
        this.password = password;
        this.FullName = FullName;
    }

   
     public void DisplayMenu()
    {
    }
      public void ToString()
    {
        System.out.println("id: " +id +"\t"+" Name: "+getFullName()+"\t"
        +" Email: "+Email +"\t"
        +" phone: "+phone +"\t"
        
        );
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String Email) {
        this.Email = Email;
    }

    /**
     * @return the Name
     */
    

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the UserName
     */
    public String getUserName() {
        return UserName;
    }

    /**
     * @param UserName the UserName to set
     */
    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }
   
    
}
