/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hdn;

/**
 *
 * @author pc
 */
public class Preview {
    private Appointment Appointment;
    private String Surgeons;
    private String ReviewDate;
    private String PreviewNote;
    public Preview() {
    }

    public Preview(Appointment Appointment, String Surgeons, String ReviewDate, String PreviewNote) {
        this.Appointment = Appointment;
        this.Surgeons = Surgeons;
        this.ReviewDate = ReviewDate;
        this.PreviewNote = PreviewNote;
    }
    
   public void ToString()
    {
         this.Appointment.ToString();
        System.out.println("Surgeons: " +Surgeons +"\t"+" ReviewDate: "+ReviewDate+"\t"
        +" PreviewNote: "+PreviewNote 
        );
    }
   
    /**
     * @return the Appointment
     */
    public Appointment getAppointment() {
        return Appointment;
    }

    /**
     * @param Appointment the Appointment to set
     */
    public void setAppointment(Appointment Appointment) {
        this.Appointment = Appointment;
    }

    /**
     * @return the Surgeons
     */
    public String getSurgeons() {
        return Surgeons;
    }

    /**
     * @param Surgeons the Surgeons to set
     */
    public void setSurgeons(String Surgeons) {
        this.Surgeons = Surgeons;
    }

    /**
     * @return the ReviewDate
     */
    public String getReviewDate() {
        return ReviewDate;
    }

    /**
     * @param ReviewDate the ReviewDate to set
     */
    public void setReviewDate(String ReviewDate) {
        this.ReviewDate = ReviewDate;
    }

    /**
     * @return the PreviewNote
     */
    public String getPreviewNote() {
        return PreviewNote;
    }

    /**
     * @param PreviewNote the PreviewNote to set
     */
    public void setPreviewNote(String PreviewNote) {
        this.PreviewNote = PreviewNote;
    }

}
